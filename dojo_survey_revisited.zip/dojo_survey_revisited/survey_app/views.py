from django.shortcuts import render, redirect

# Create your views here.

def survey(request):
    return render(request, "survey.html")

def results(request):
    if request.method == 'GET':
        return redirect('/')
    request.session['result'] = {
        "name": request.POST["name"],
        "location": request.POST["location"],
        "language": request.POST["language"],
        "comment": request.POST["comment"],
    } 
    return redirect('/result')

def result(request):
    context = {
        'result': request.session['result']
    }
    return render(request, 'results.html', context)