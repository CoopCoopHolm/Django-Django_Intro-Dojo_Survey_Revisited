from django.urls import path
from . import views

urlpatterns = [
    path('', views.survey),
    path('survey', views.results),
    path('result', views.result),
]